package com.example.books.controller;

import com.example.books.exception.ResourceNotFoundException;
import com.example.books.model.Book;
import com.example.books.repository.BookRepository;
import com.example.books.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController
{
    @Autowired
    private BookService bookService;

    @GetMapping("/getbooks")
    public ResponseEntity<List<Book>> getAllBooks()
    {
        return new ResponseEntity<>(bookService.getAllBooks(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id)
    {
        return new ResponseEntity<>(bookService.getBookById(id),HttpStatus.OK);
    }

    @PostMapping("/addbooks")
    public ResponseEntity<Book> saveEmployee(@RequestBody Book book)
    {
        return new ResponseEntity<>(bookService.addBook(book),HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateBook(@PathVariable Long id, @RequestBody Book book)
    {
        return new ResponseEntity<>(bookService.updateBook(id, book), HttpStatus.OK);

    }

    @GetMapping("/filter")
    public ResponseEntity<List<Book>> getBooksByFilter(@RequestParam(required = false) String bookName,
                                                       @RequestParam(required = false) String authorName)
    {
        try
        {
            List<Book> books = bookService.getBooksByFilter(bookName, authorName);
            return ResponseEntity.ok().body(books);
        }
        catch (ResourceNotFoundException e)
        {
            return ResponseEntity.notFound().build();
        }
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable Long id)
    {
        bookService.deleteBook(id);

        if(true)
        {
            return new ResponseEntity<String>("Book successfully deleted with id: "+id,HttpStatus.OK);
        }
        return new ResponseEntity<String>(HttpStatus.OK);
    }
}
