package com.example.books.exception;

public class DuplicateEntryException extends RuntimeException{
    public DuplicateEntryException(String Message)
    {
        super(Message);
    }
}
